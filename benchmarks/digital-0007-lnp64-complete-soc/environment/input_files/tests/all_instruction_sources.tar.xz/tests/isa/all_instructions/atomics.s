# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
.data
atomic_word: .quad 10
             .quad 0
atomic_pair: .quad 1
             .quad 2

.text
  LI r1, atomic_word
  LI r2, 3
  LI r10, 10

  ST [r1, 0], r10
  AMO.ADD.D r8, (r1), r2            # SEMANTIC: amo.add guest-amo-transition-v1
  LI r11, 13
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r11, bad

  ST [r1, 0], r10
  AMO.AND.D r8, (r1), r2            # SEMANTIC: amo.and guest-amo-transition-v1
  LI r11, 2
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r11, bad

  ST [r1, 0], r10
  AMO.OR.D r8, (r1), r2             # SEMANTIC: amo.or guest-amo-transition-v1
  LI r11, 11
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r11, bad

  ST [r1, 0], r10
  AMO.XOR.D r8, (r1), r2            # SEMANTIC: amo.xor guest-amo-transition-v1
  LI r11, 9
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r11, bad

  ST [r1, 0], r10
  AMO.NAND.D r8, (r1), r2           # SEMANTIC: amo.nand guest-amo-transition-v1
  LI r11, 2
  NOT r11, r11
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r11, bad

  ST [r1, 0], r10
  AMO.SWAP.D r8, (r1), r2           # SEMANTIC: amo.swap guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r2, bad

  ST [r1, 0], r10
  AMO.MIN.D r8, (r1), r2            # SEMANTIC: amo.min guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r2, bad

  ST [r1, 0], r10
  AMO.MAX.D r8, (r1), r2            # SEMANTIC: amo.max guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r10, bad

  ST [r1, 0], r10
  AMO.MINU.D r8, (r1), r2           # SEMANTIC: amo.minu guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r2, bad

  ST [r1, 0], r10
  AMO.MAXU.D r8, (r1), r2           # SEMANTIC: amo.maxu guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r10, bad

  ST [r1, 0], r10
  AMO.CAS.D r8, (r1), r10, r2       # SEMANTIC: amo.cas guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r10, bad
  BNE r9, r2, bad

  LI r1, atomic_pair
  LI r4, 1
  LI r5, 2
  LI r6, 3
  LI r7, 4
  AMO.CASQ r8, (r1), r4, r6         # SEMANTIC: amo.casq guest-amo-transition-v1
  LDP r12, 0(r1)
  BNE r8, r4, bad
  BNE r9, r5, bad
  BNE r12, r6, bad
  BNE r13, r7, bad

  LI r1, atomic_word
  LI r2, 1
  ST [r1, 0], r0
  AMO.FADD.F64 r8, (r1), r2          # SEMANTIC: amo.fadd guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r0, bad
  BNE r9, r2, bad

  ST [r1, 0], r0
  AMO.FMIN.F64 r8, (r1), r2          # SEMANTIC: amo.fmin guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r0, bad
  BNE r9, r0, bad

  ST [r1, 0], r0
  AMO.FMAX.F64 r8, (r1), r2          # SEMANTIC: amo.fmax guest-amo-transition-v1
  LD r9, [r1, 0]
  BNE r8, r0, bad
  BNE r9, r2, bad

  EXIT r0
bad:
  LI r1, 1
  EXIT r1
