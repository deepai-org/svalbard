# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked external-pager, supply, and range-observation semantics.
.data
range_record: .zero 16

.text
  # A record endpoint is a typed pager relationship.
  LI r2, 1
  channel.new r10, r2
  LI r3, 8
  channel.capacity r10, r10, r3
  channel.producer r10, r10, r0
  channel.consumer r10, r10, r0
  LI r3, 24
  channel.schema r10, r10, r3
  channel.acceptance r10, r10, r0
  channel.seal r11, r10

  LI r2, 8192
  backing.new r12, r2, r0
  backing.pager r12, r12, r11           # SEMANTIC: backing.pager guest-paged-backing-v1
  backing.charge r12, r12, r0
  backing.seal r13, r12
  BLE r13, r0, bad

  # Epoch one is the initial pager designation.  A null source explicitly
  # installs zero-filled bytes and records both accessed and dirty truth.
  LI r2, 4096
  LI r3, 1
  backing.supply r14, r13, r0, r2, r0, r3 # SEMANTIC: backing.supply guest-paged-backing-v1
  BNE r14, r0, bad
  # A nonexistent generation-qualified request is rejected without touching
  # data or the backing's administrative default charge target.
  LI r4, 0x1234
  backing.supply_req r14, r13, r4, r0, r3 # SEMANTIC: backing.supply_req guest-paged-request-v1
  LI r5, -3
  BNE r14, r5, bad
  accessed.begin r15, r13, r0, r2, 0    # SEMANTIC: accessed.begin guest-backing-cursor-v1
  BLE r15, r0, bad
  LI r4, range_record
  cursor.next r14, r15, r4
  BNE r14, r0, bad
  LD r5, [r4, 0]
  BNE r5, r0, bad
  LD r5, [r4, 8]
  BNE r5, r2, bad
  cursor.end r15

  # Dirty generations are bit-exact and the class-local next spelling returns
  # the same frozen range record through its own assigned function.
  writegen.rotate r6, r13
  LI r7, 2
  BNE r6, r7, bad
  LI r3, 1
  dirty.begin r15, r13, r3, r6, r0, r2 # SEMANTIC: dirty.begin guest-backing-cursor-v1
  BLE r15, r0, bad
  dirty.next r14, r15, r4               # SEMANTIC: dirty.next guest-backing-cursor-v1
  BNE r14, r0, bad
  cursor.end r15

  # Pager rebinding is permitted only under a caller-owned quiescence token.
  LI r2, 2
  # The token is caller-owned and authorizes the pager transition while the
  # owning Domain's memory-mutation surface is held.
  quiesce r16, r0, r2                   # SEMANTIC: lifecycle.quiesce guest-lifecycle-hold-v1
  BLE r16, r0, bad
  backing.rebind_pager r14, r13, r16, r11 # SEMANTIC: backing.rebind_pager guest-paged-backing-v1
  BNE r14, r0, bad
  backing.detach_pager r14, r13, r16    # SEMANTIC: backing.detach_pager guest-paged-backing-v1
  BNE r14, r0, bad
  resume r14, r16                       # SEMANTIC: lifecycle.resume guest-lifecycle-hold-v1
  BNE r14, r0, bad

  # Reject validates request id, designation epoch, and the closed condition enum;
  # with no outstanding request, the stable terminal answer is STALE.
  LI r2, 1
  LI r3, 1
  LI r4, 6
  backing.reject r14, r13, r2, r3, r4 # SEMANTIC: backing.reject guest-paged-backing-v1
  LI r5, -3
  BNE r14, r5, bad

  # Specialized constructors return live PagedBacking capabilities directly.
  LI r2, 4096
  backing.code r17, r2                  # SEMANTIC: backing.code guest-backing-special-v1
  BLE r17, r0, bad
  LI r3, 4096
  backing.contig r18, r2, r3            # SEMANTIC: backing.contig guest-backing-special-v1
  BLE r18, r0, bad

  lifecycle.destroy r1, r18             # SEMANTIC: lifecycle.destroy guest-object-destroy-v1
  lifecycle.destroy r1, r17
  lifecycle.destroy r1, r13
  lifecycle.destroy r1, r11
  EXIT r0
bad:
  LI r1, 1
  EXIT r1
