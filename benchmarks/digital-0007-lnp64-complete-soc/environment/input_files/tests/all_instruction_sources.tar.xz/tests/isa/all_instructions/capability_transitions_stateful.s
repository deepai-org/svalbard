# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Capability lineage, atomic move, stamp rejection, and identity-cell tokens.
.text
  # cap.move chooses a receiver slot, preserves the referent/rights requested,
  # and consumes the sender slot atomically.  Zero is the typed self Domain.
  LI r2, 0x4142
  counter.new r10, r0, r2
  cap.rights r11, r10
  cap.move r12, r10, r0, r11           # SEMANTIC: cap.move guest-cap-move-domain-v1
  BLE r12, r0, bad
  counter.read r13, r12
  BNE r13, r2, bad
  cap.drop r14, r10
  LI r15, -3
  BNE r14, r15, bad

  # Each lineage transition revokes the complete lineage and acknowledges
  # success; the original handle is stale immediately afterward.
  LI r2, 1
  counter.new r10, r0, r2
  cap.revoke r14, r10                  # SEMANTIC: cap.revoke guest-cap-revoke-v1
  BNE r14, r0, bad
  cap.drop r14, r10
  BNE r14, r15, bad

  counter.new r10, r0, r2
  cap.revoke_cancel r14, r10           # SEMANTIC: cap.revoke_cancel guest-cap-revoke-cancel-v1
  BNE r14, r0, bad
  cap.drop r14, r10
  BNE r14, r15, bad

  counter.new r10, r0, r2
  cap.revoke_wait r14, r10             # SEMANTIC: cap.revoke_wait guest-cap-revoke-wait-v1
  BNE r14, r0, bad
  cap.drop r14, r10
  BNE r14, r15, bad

  counter.new r10, r0, r2
  cap.revoke_poison r14, r10           # SEMANTIC: cap.revoke_poison guest-cap-revoke-poison-v1
  BNE r14, r0, bad
  cap.drop r14, r10
  LI r15, -19
  BNE r14, r15, bad

  # An ordinary hardware capability is not a stamped service relationship.
  # RESTAMP must reject it without consuming either operand.
  counter.new r10, r0, r2
  counter.new r11, r0, r2
  cap.restamp r14, r10, r11            # SEMANTIC: cap.restamp guest-cap-restamp-typecheck-v1
  LI r15, -2
  BNE r14, r15, bad
  counter.read r14, r10
  BNE r14, r2, bad

  # Repoint preparation is a single-use token.  Abort makes commit stale;
  # a fresh token commits the (idempotent) self-to-self identity transition.
  LI r2, -1
  cell.repoint.prepare r16, r0, r0, r0, r2 # SEMANTIC: cell.repoint.prepare guest-cell-repoint-v1
  BLE r16, r0, bad
  cell.repoint.abort r16                # SEMANTIC: cell.repoint.abort guest-cell-repoint-v1
  cell.repoint.commit r17, r16
  LI r15, -3
  BNE r17, r15, bad

  cell.repoint.prepare r16, r0, r0, r0, r2
  BLE r16, r0, bad
  cell.repoint.commit r17, r16          # SEMANTIC: cell.repoint.commit guest-cell-repoint-v1
  BNE r17, r0, bad

  counter.destroy r1, r12
  counter.destroy r1, r10
  counter.destroy r1, r11
  EXIT r0
bad:
  LI r1, 1
  EXIT r1
