# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# A zero-delay Timer publishes a CompletionQueue record; channel.peek must
# expose that record without consuming it.
.data
record: .zero 24
.text
  LI r2, 4
  cqueue.new r10, r0, r2

  clock.new r11, r0
  timer.new r12, r0
  timer.clock r12, r12, r11
  timer.delivery_queue r12, r12, r10
  timer.seal r13, r12
  LI r2, 1
  timer.arm_rel r14, r13, r2, r0
  BLE r14, r0, bad

  LI r15, record
  channel.peek r16, r10, r15          # SEMANTIC: channel.peek guest-channel-peek-v1
  BNE r16, r0, bad
  LD r17, [r15, 0]
  BNE r17, r14, bad
  LD r17, [r15, 8]
  BNE r17, r0, bad
  LD r17, [r15, 16]
  LI r18, 1
  BNE r17, r18, bad

  # A subsequent consuming receive observes the same record, proving peek did
  # not advance the queue.
  cqueue.recv r16, r10, r15
  BNE r16, r0, bad
  cqueue.destroy r1, r10
  timer.destroy r1, r13
  clock.destroy r1, r11
  EXIT r0
bad:
  LI r1, 1
  EXIT r1
