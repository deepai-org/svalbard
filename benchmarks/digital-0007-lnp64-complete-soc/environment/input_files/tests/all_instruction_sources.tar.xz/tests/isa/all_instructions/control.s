# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
.text
  LI r1, 1
  LI r2, 2
  AUIPC r3, 0
  JMP after_jmp
after_jmp:
  JAL r10, after_jal
after_jal:
  LI r11, after_jalr
  JALR r10, r11, 0
after_jalr:
  BEQ r1, r2, bad
  BNE r1, r1, bad
  BLT r2, r1, bad
  BGE r1, r2, bad
  BLTU r2, r1, bad
  BGEU r1, r2, bad
  BEQI r1, 2, bad

  LI r11, cfi_target
  JALR.CFI r10, r11, 0
cfi_target:
  LPAD

  TEQ r1, r2, 1
  TEQI r1, 2, 1
  TRAP 1                              # SEMANTIC: trap trap-sigill-kind-v1

bad:
  EXIT r1
