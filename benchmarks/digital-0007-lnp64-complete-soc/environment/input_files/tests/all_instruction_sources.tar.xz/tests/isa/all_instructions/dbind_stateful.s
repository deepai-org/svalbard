# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked queue-free prepared service binding publication.
.text
  gate.new r10, r0
  LI r2, gate_entry
  gate.entry r10, r10, r2
  LI r2, 0x70000
  LI r3, 4096
  LI r4, 1
  gate.stack r10, r10, r2, r3, r4
  LI r2, 64
  LI r3, 0
  LI r4, 0
  gate.limits r10, r10, r2, r3, r4
  LI r2, 0
  gate.abi r10, r10, r2
  gate.seal r11, r10
  BLE r11, r0, bad

  dnew r12, r0
  LI r2, 9
  dservice r12, r12, r2, r11
  LI r3, 1
  LI r4, 0xfeedcafe
  LI r5, 1000000
  dbind.prepare r12, r12, r2, r3, r4, r5 # SEMANTIC: dbind.prepare guest-prepared-binding-v1
  BLE r12, r0, bad
  dseal r13, r12
  BLE r13, r0, bad

  dkill r1, r13
  lifecycle.destroy r1, r11
  EXIT r0

gate_entry:
  # The coordinator would obtain the token through an ordinary call. This
  # focused fixture does not invoke it because dbind.prepare receives the
  # already-issued opaque token and never dispatches implicitly.
  GATE_RETURN r1, r0
  LI r1, 1
  EXIT r1

bad:
  LI r1, 1
  EXIT r1
