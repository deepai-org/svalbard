# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked immutable Device construction, discovery, and member access.
.data
member_record: .zero 24

.text
  LI r2, 0x1234
  device.new r10, r2                    # SEMANTIC: device.new guest-device-bundle-v1
  BLE r10, r0, bad

  LI r2, 0x55aa
  counter.new r11, r0, r2
  LI r2, 7
  device.member r10, r10, r2, r11       # SEMANTIC: device.member guest-device-bundle-v1
  BLE r10, r0, bad
  LI r2, 9
  LI r3, 0xfeedbeef
  device.scalar r10, r10, r2, r3        # SEMANTIC: device.scalar guest-device-bundle-v1
  BLE r10, r0, bad
  device.seal r12, r10                  # SEMANTIC: device.seal guest-device-bundle-v1
  BLE r12, r0, bad

  device.profile r13, r12               # SEMANTIC: device.profile guest-device-bundle-v1
  LI r2, 0x1234
  BNE r13, r2, bad
  LI r2, 9
  device.scalar_get r13, r12, r2        # SEMANTIC: device.scalar_get guest-device-bundle-v1
  LI r3, 0xfeedbeef
  BNE r13, r3, bad
  LI r2, 7
  device.get r14, r12, r2               # SEMANTIC: device.get guest-device-bundle-v1
  BLE r14, r0, bad
  counter.read r15, r14
  LI r2, 0x55aa
  BNE r15, r2, bad

  LI r2, 0
  objenum.begin r16, r12, r2
  BLE r16, r0, bad
  LI r2, member_record
  cursor.next r17, r16, r2
  BNE r17, r0, bad
  LW r18, [r2, 0]
  LI r3, 7
  BNE r18, r3, bad
  LW r18, [r2, 4]
  BNE r18, r0, bad
  LD r18, [r2, 8]
  BNE r18, r0, bad
  LW r18, [r2, 20]
  LI r3, 3
  BNE r18, r3, bad
  cursor.end r16

  cap.drop r1, r14
  lifecycle.destroy r1, r12
  counter.destroy r1, r11
  EXIT r0

bad:
  LI r1, 1
  EXIT r1
