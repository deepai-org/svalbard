# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked pinned DMAWindow lifecycle and extent observability.
.data
extent_batch: .quad 0x2000
              .quad 0x1000
              .quad 0x1000
extent_record: .zero 40

.text
  LI r2, 0x4000
  backing.new r10, r2, r0
  backing.charge r10, r10, r0
  backing.seal r11, r10
  BLE r11, r0, bad

  window.new r12, r0                    # SEMANTIC: window.new guest-dma-window-v1
  window.scope r12, r12, r11            # SEMANTIC: window.scope guest-dma-window-v1
  # Device authority is the typed requester relation.  Mint it locally so
  # this ISA semantic test is profile-independent; reset-device discovery is
  # covered by the separate platform attach test.
  LI r2, 257
  device.new r2, r2
  device.seal r2, r2
  BEQ r2, r0, bad
  ADDI r23, r2, 0
  window.device r12, r12, r2            # SEMANTIC: window.device guest-dma-window-v1
  LI r2, 1
  window.ats r12, r12, r2               # SEMANTIC: window.ats guest-dma-window-v1
  window.pin r12, r12                    # SEMANTIC: window.pin guest-dma-window-v1
  window.seal r13, r12                   # SEMANTIC: window.seal guest-dma-window-v1
  BLE r13, r0, bad

  window.generation r14, r13             # SEMANTIC: window.generation guest-dma-window-v1
  LI r2, 1
  BNE r14, r2, bad
  window.acknowledged r15, r13            # SEMANTIC: window.acknowledged guest-dma-window-v1
  BNE r15, r0, bad
  window.direction r15, r13               # SEMANTIC: window.direction guest-dma-window-v1
  BNE r15, r0, bad
  window.status r15, r13                  # SEMANTIC: window.status guest-dma-window-v1
  BNE r15, r0, bad
  window.transient_pins r15, r13          # SEMANTIC: window.transient_pins guest-dma-window-v1
  BNE r15, r0, bad

  # A single remap and a bulk remap both advance and acknowledge one installed
  # generation.  Extents are page-aligned and backing-relative.
  LI r2, 0
  LI r3, 0
  LI r4, 0x1000
  window.remap_one r14, r13, r2, r3, r4  # SEMANTIC: window.remap_one guest-dma-window-v1
  LI r5, 2
  BNE r14, r5, bad
  LI r2, extent_batch
  LI r3, 1
  window.remap r14, r13, r2, r3          # SEMANTIC: window.remap guest-dma-window-v1
  LI r5, 3
  BNE r14, r5, bad
  window.acknowledged r15, r13
  BNE r15, r14, bad

  # Enumeration exposes a frozen extent record and is exhausted explicitly.
  window.extents r16, r13                 # SEMANTIC: window.extents guest-dma-window-v1
  BLE r16, r0, bad
  LI r2, extent_record
  cursor.next r17, r16, r2                # SEMANTIC: cursor.next guest-dma-window-cursor-v1
  BNE r17, r0, bad
  LD r18, [r2, 8]
  BNE r18, r0, bad
  cursor.end r16                          # SEMANTIC: cursor.end guest-dma-window-cursor-v1

  # Submission facets are distinct nonzero capabilities derived from the same
  # live window; creation does not mutate its installed generation.
  window.copy_facet r19, r13              # SEMANTIC: window.copy_facet guest-dma-window-v1
  window.fill_facet r20, r13              # SEMANTIC: window.fill_facet guest-dma-window-v1
  window.copyv_facet r21, r13             # SEMANTIC: window.copyv_facet guest-dma-window-v1
  window.copy_hash_facet r22, r13         # SEMANTIC: window.copy_hash_facet guest-dma-window-v1
  window.requester_facet r23, r13         # SEMANTIC: window.requester_facet guest-dma-requester-backing-v1
  BLE r19, r0, bad
  BLE r20, r0, bad
  BLE r23, r0, bad
  BLE r21, r0, bad
  BLE r22, r0, bad

  # Abort consumes an independent unpublished builder.
  window.new r12, r0
  window.abort r12                        # SEMANTIC: window.abort guest-dma-window-abort-v1

  lifecycle.destroy r1, r13
  lifecycle.destroy r1, r23
  EXIT r0
bad:
  LI r1, 1
  EXIT r1
