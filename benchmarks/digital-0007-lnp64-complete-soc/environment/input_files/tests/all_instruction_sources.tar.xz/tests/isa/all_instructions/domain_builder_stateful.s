# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Stateful, guest-checked DomainBuilder semantics.  This deliberately keeps
# children unpublished/non-running unless a publication result is inspected.
.data
initial_context: .zero 256

.text
  # A fresh builder accepts independent policy facts and threads the returned
  # builder generation through the same architectural register.
  dnew r10, r0                         # SEMANTIC: dnew guest-domain-builder-v1
  BEQ r10, r0, bad
  LI r2, 7
  dsched.timeshare r10, r10, r2        # SEMANTIC: dsched.timeshare guest-domain-builder-v1
  LI r2, 3
  dsched.fixed r10, r10, r2            # SEMANTIC: dsched.fixed guest-domain-builder-v1
  LI r2, 10
  LI r3, 100
  dsched.reservation r10, r10, r2, r3  # SEMANTIC: dsched.reservation guest-domain-builder-v1
  LI r2, 0
  LI r3, 4096
  dbudget r10, r10, r2, r3             # SEMANTIC: dbudget guest-domain-builder-v1
  LI r2, 1
  LI r3, 8
  dbudget.charge_through r10, r10, r2, r3 # SEMANTIC: dbudget.charge_through guest-domain-builder-v1
  snew r11
  LI r2, 0
  sadd r11, r11, r2
  dplace r10, r10, r11                 # SEMANTIC: dplace guest-domain-builder-v1
  LI r2, 0
  djit r10, r10, r2                    # SEMANTIC: djit guest-domain-builder-v1
  LI r2, 0
  dabi r10, r10, r2                    # SEMANTIC: dabi guest-domain-builder-v1
  LI r2, 4096
  dstack.new r10, r10, r2              # SEMANTIC: dstack.new guest-domain-builder-v1
  LI r2, 0
  LI r3, child_entry
  dentry r10, r10, r2, r3              # SEMANTIC: dentry guest-domain-builder-v1
  LI r2, 0
  dgates r10, r10, r2, r3              # SEMANTIC: dgates guest-domain-builder-v1
  dmeasure r10, r10                     # SEMANTIC: dmeasure guest-domain-builder-v1

  # Anonymous mappings begin inaccessible; protection assignment and placement
  # operate on the prospective mapping before publication.
  LI r2, 0x40000
  LI r3, 4096
  dmap r10, r10, r0, r2, r3, r0        # SEMANTIC: dmap guest-domain-builder-v1
  LI r4, 3
  dprotect r10, r10, r2, r3, r4        # SEMANTIC: dprotect guest-domain-builder-v1
  LI r4, -1
  dhome r10, r10, r2, r3, r4           # SEMANTIC: dhome guest-domain-builder-v1
  dunmap r10, r10, r2, r3              # SEMANTIC: dunmap guest-domain-builder-v1

  # Register-state capture is a checked snapshot of 32 words.
  LI r2, initial_context
  dstate.registers r10, r10, r2         # SEMANTIC: dstate.registers guest-domain-builder-v1

  # Self authority and slot policy facts are accepted.  Grant a real Counter
  # capability, then narrow/seal/name its replacement lifetime in the child.
  LI r2, 0xffff
  dself r10, r10, r2                    # SEMANTIC: dself guest-domain-builder-v1
  LI r2, 1
  LI r3, 0
  counter.new r12, r0, r3
  cap.rights r13, r12
  LI r14, 5
  dgrant r10, r10, r12, r13, r14        # SEMANTIC: dgrant guest-domain-builder-v1
  dlimit r10, r10, r14, r13             # SEMANTIC: dlimit guest-domain-builder-v1
  dsealcap r10, r10, r14                # SEMANTIC: dsealcap guest-domain-builder-v1
  dslot.persist r10, r10, r14           # SEMANTIC: dslot.persist guest-domain-builder-v1
  dslot.drop_on_replace r10, r10, r14   # SEMANTIC: dslot.drop_on_replace guest-domain-builder-v1

  # A ClockView is a constructible delegated relation.  The physical
  # MachineView and service relationship are not ambient: zero must fail as a
  # bad reference without corrupting the builder.
  clock.new r15, r0
  dclock r10, r10, r15                   # SEMANTIC: dclock guest-domain-builder-v1
  dview r16, r10, r12                    # SEMANTIC: dview guest-domain-builder-badref-v1
  LI r17, -2
  BNE r16, r17, bad
  LI r2, 6
  dservice r16, r10, r2, r12             # SEMANTIC: dservice guest-domain-builder-badref-v1
  BNE r16, r17, bad

  # Publication consumes the builder and returns a distinct child identity.
  dseal r18, r10                         # SEMANTIC: dseal guest-domain-builder-v1
  BLE r18, r0, bad
  dget r19, r18, r0                     # SEMANTIC: dget guest-domain-builder-publication-v1
  LI r20, 1
  BNE r19, r20, bad

  # Fork and compartment builders are independently typed and abort consumes
  # each without publishing anything.
  dfork r10, r0                         # SEMANTIC: dfork guest-domain-builder-v1
  BLE r10, r0, bad
  dabort r10                            # SEMANTIC: dabort guest-domain-builder-v1
  dcompartment r10, r0                  # SEMANTIC: dcompartment guest-domain-builder-v1
  BLE r10, r0, bad
  dabort r10

  # Explicit move and dense-mask transfers stage authority without consuming
  # their sources until publication.  Aborting therefore leaves every source
  # capability usable.
  LI r2, 0
  LI r3, 2
  counter.new r22, r2, r3
  cap.rights r23, r22
  dnew r10, r0
  LI r24, 7
  dmove r10, r10, r22, r23, r24         # SEMANTIC: dmove guest-domain-builder-v1
  dabort r10
  counter.read r1, r22
  BNE r1, r3, bad

  # Mask bit zero names r2 and dense-packs it at slot_base.  Use separate
  # builders so copy and staged-move are each independently observable.
  OR r2, r12, r0
  LI r3, 8
  LI r4, 1
  dnew r10, r0
  dgrantm r10, r10, r3, r4              # SEMANTIC: dgrantm guest-domain-builder-v1
  dabort r10
  OR r2, r22, r0
  dnew r10, r0
  dmovem r10, r10, r3, r4               # SEMANTIC: dmovem guest-domain-builder-v1
  dabort r10
  counter.read r1, r22
  LI r3, 2
  BNE r1, r3, bad

  # A caller-provided stack range is a distinct builder fact.  Its basic
  # alignment/extent constraints are checked at mutation time.
  dnew r10, r0
  LI r2, 0x70000
  LI r3, 4096
  dstack.use r10, r10, r2, r3            # SEMANTIC: dstack.use guest-domain-builder-v1
  dabort r10

  # Start requires a defined entry index; absence is a stable malformed
  # result and leaves the builder available for abort.
  dnew r10, r0
  LI r2, 0
  dstart r16, r10, r2                    # SEMANTIC: dstart guest-domain-builder-malformed-v1
  LI r17, -4
  BNE r16, r17, bad
  dabort r10

  # The compact spawn encoding rejects reserved high bits before creating a
  # child or consuming a staged move.
  LI r2, 0
  LI r3, 0
  LI r4, 0
  LI r5, 1
  LI r6, 40
  LSL r5, r5, r6
  dspawn r16, r2, r3, r4, r5             # SEMANTIC: dspawn guest-domain-spawn-malformed-v1
  BNE r16, r17, bad

  # Replacement is a separate builder kind.  Mode and STARTUP metadata are
  # accepted only on that kind.  A builder with no staged executable mapping,
  # stack, or entry must fail commit atomically and remain abortable; a
  # successful replacement deliberately does not return to this instruction
  # stream (§11.5), and is exercised by the dedicated replacement tests.
  dreplace r10, r18                      # SEMANTIC: dreplace guest-domain-replace-v1
  BLE r10, r0, bad
  LI r2, 2
  dreplace.mode r10, r10, r2             # SEMANTIC: dreplace.mode guest-domain-replace-v1
  dstartup r10, r10, r0                  # SEMANTIC: dstartup guest-domain-replace-v1
  dreplace.commit r16, r10               # SEMANTIC: dreplace.commit guest-domain-replace-v1
  LI r17, -4
  BNE r16, r17, bad
  dabort r10

  # Shared map requires a real backing.  This verifies class/right checking as
  # well as the distinct shared staged relation.
  LI r2, 4096
  backing.new r20, r2, r0
  backing.charge r20, r20, r0
  backing.seal r21, r20
  dnew r10, r0
  LI r3, 0x50000
  dmap.shared r10, r10, r21, r3, r2, r0 # SEMANTIC: dmap.shared guest-domain-builder-v1
  dabort r10

  # Invalid range copies are rejected before state mutation.  These boundary
  # checks give each startup relation an observable, specification-defined
  # result even though this fixture has no spare mapped source page.
  dnew r10, r0
  LI r2, 1
  LI r3, 0x60000
  LI r4, 4096
  dstate.cow r16, r10, r0, r2, r3, r4   # SEMANTIC: dstate.cow guest-domain-builder-malformed-v1
  LI r17, -4
  BNE r16, r17, bad
  dstate.move r16, r10, r2, r3, r4      # SEMANTIC: dstate.move guest-domain-builder-malformed-v1
  BNE r16, r17, bad
  dstate.share_ro r16, r10, r2, r3, r4  # SEMANTIC: dstate.share_ro guest-domain-builder-malformed-v1
  BNE r16, r17, bad
  dabort r10

  clock.destroy r1, r15
  counter.destroy r1, r12
  counter.destroy r1, r22
  lifecycle.destroy r1, r18
  EXIT r0

child_entry:
  dexit r0
bad:
  LI r1, 1
  EXIT r1
