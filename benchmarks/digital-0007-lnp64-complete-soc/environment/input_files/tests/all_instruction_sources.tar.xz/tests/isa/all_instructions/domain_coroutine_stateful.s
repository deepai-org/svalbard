# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Full coroutine hop: dcall -> dyield -> dresume -> dret.
.text
  # This coroutine executes code from the caller's image.  dnew is an empty
  # prospective address space; dfork is the architected COW-image builder.
  dfork r10, r0
  LI r2, 0
  LI r3, coroutine_entry
  dentry r10, r10, r2, r3
  dseal r11, r10
  BLE r11, r0, bad

  LI r2, 0
  dcall r12, r11, r2
  # The first reply is a yield: value in call rd, nonzero ActivationRef in r3.
  LI r4, 0x71
  BNE r12, r4, bad
  BEQ r3, r0, bad
  ADDI r13, r3, 0
  LI r5, 0x82
  dresume r14, r13, r5
  # The resumed activation returned terminally through DRET.
  LI r4, 0x93
  BNE r14, r4, bad
  BNE r3, r0, bad
  EXIT r0

coroutine_entry:
  LI r7, 0x71
  dyield r8, r7                       # SEMANTIC: dyield guest-domain-coroutine-v1
  LI r9, 0x82
  BNE r8, r9, coroutine_bad
  LI r7, 0x93
  dret r7                             # SEMANTIC: dret guest-domain-coroutine-v1
coroutine_bad:
  LI r7, -1
  dret r7

bad:
  LI r1, 1
  EXIT r1
