# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked live Domain and thread-control semantics.
.data
child_stack:
clear_tid_word: .quad 1
  .zero 4088

.text
  # Create two inert children so hierarchy and lifecycle operations have real
  # targets without introducing scheduling races.
  # Fork retains the caller's executable image.  Giving it an explicit entry
  # makes the later tail-call error test validate a real entry before it
  # checks the empty-continuation condition.
  dfork r10, r0
  LI r2, 0
  LI r3, child_entry
  dentry r10, r10, r2, r3
  dseal r11, r10
  BLE r11, r0, bad
  dnew r10, r0
  dseal r12, r10
  BLE r12, r0, bad

  # Pair getter returns charged and ceiling in independently named registers.
  LI r2, 0
  dget2 r13, r14, r11, r2             # SEMANTIC: dget2 guest-live-domain-v1
  LI r3, 12345
  domain.budget r15, r11, r2, r3      # SEMANTIC: domain.budget guest-live-domain-v1
  BNE r15, r0, bad
  dget2 r13, r14, r11, r2
  BNE r14, r3, bad

  # Placement and reservation update independently.  Placement happens first
  # because a live reservation requires quiescence before relocation.
  snew r16
  LI r2, 0
  sadd r16, r16, r2
  domain.place r15, r11, r16          # SEMANTIC: domain.place guest-live-domain-v1
  BNE r15, r0, bad
  # Reparenting updates the hierarchy atomically and refuses cycles in the
  # implementation; this is the positive sibling-to-child relation.
  dreparent r15, r11, r12             # SEMANTIC: dreparent guest-live-domain-v1
  BNE r15, r0, bad
  LI r2, 10
  LI r3, 100
  domain.reserve r15, r11, r2, r3     # SEMANTIC: domain.reserve guest-live-domain-v1
  BNE r15, r0, bad

  # Per-thread scheduling can only narrow within the owning Domain.  Root is
  # timeshare, so its own current thread accepts the class-0 neutral policy.
  GET_PCR r17, THREAD_ID
  LI r2, 0
  thread.sched r15, r17, r2, r0, r0   # SEMANTIC: thread.sched guest-live-domain-v1
  BNE r15, r0, bad
  thread.place r15, r17, r16           # SEMANTIC: thread.place guest-live-domain-v1
  BNE r15, r0, bad

  # Group eligibility is a generation-qualified thread fact.  Updating the
  # generation makes an earlier posting snapshot stale rather than silently
  # retargeting it.
  LI r2, 0x1234
  LI r3, 0x31
  thread.group r15, r0, r17, r2, r3    # SEMANTIC: thread.group guest-thread-group-generation-v1
  BNE r15, r0, bad

  # A persistent second thread is born in this Domain and terminates itself;
  # clear-tid registration is independently exercised on the calling thread.
  LI r2, child_entry
  LI r3, 0x55
  LI r4, child_stack
  LI r5, 4096
  thread.new r18, r2, r3, r4, r5       # SEMANTIC: thread.new guest-thread-lifecycle-v1
  BLE r18, r0, bad
  LI r6, clear_tid_word
  thread.ctid r15, r6                  # SEMANTIC: thread.ctid guest-thread-lifecycle-v1
  BNE r15, r0, bad

  # The all-zero rseq descriptor unregisters atomically and is idempotent.
  thread.rseq r15, r0, r0, r0, r0     # SEMANTIC: thread.rseq guest-live-domain-v1
  BNE r15, r0, bad

  # Event policy is mutable only for self.  Ignoring event 7 still permits a
  # well-formed software post, while an out-of-range event is malformed.
  LI r2, 7
  LI r3, 1
  event.disposition r15, r0, r2, r3   # SEMANTIC: event.disposition guest-live-domain-v1
  BNE r15, r0, bad
  event.default r15, r0, r3            # SEMANTIC: event.default guest-live-domain-v1
  BNE r15, r0, bad
  LI r4, 0x55
  # target_kind 0 is ANY and therefore carries the canonical zero selector.
  LI r6, 0
  event.post r15, r0, r2, r4, r6, r0   # SEMANTIC: event.post guest-live-domain-v1
  BNE r15, r0, bad

  # A call to an out-of-bounds entry and a tail call with no continuation have
  # precise condition results and cannot transfer control.
  LI r2, 0x7fffffff
  dcall r15, r0, r2                    # SEMANTIC: dcall guest-domain-call-bounds-v1
  LI r3, -6
  BNE r15, r3, bad
  LI r2, 0
  dtail r11, r2                        # SEMANTIC: dtail guest-domain-tail-malformed-v1
  LI r3, -4
  BNE r1, r3, bad

  # An unknown ActivationRef is stale and is not consumed from any unrelated
  # state.  r3 may not be the destination, but r15 is ordinary.
  LI r2, 0x1234
  LI r3, 0x99
  dresume r15, r2, r3                  # SEMANTIC: dresume guest-domain-resume-stale-v1
  LI r4, -3
  BNE r15, r4, bad

  # Stop establishes the quiesced state; kill makes a corpse and join observes
  # its terminal state without blocking.
  dstop r15, r11                       # SEMANTIC: dstop guest-live-domain-lifecycle-v1
  BNE r15, r0, bad
  dget r15, r11, r0
  LI r2, 2
  BNE r15, r2, bad
  dkill r15, r11                       # SEMANTIC: dkill guest-live-domain-lifecycle-v1
  BNE r15, r0, bad
  djoin r15, r11, r0                   # SEMANTIC: djoin guest-live-domain-lifecycle-v1
  BNE r15, r0, bad
  dkill r15, r12
  BNE r15, r0, bad

  dexit r0                             # SEMANTIC: dexit guest-domain-exit-v1
bad:
  LI r1, 1
  dexit r1

child_entry:
  thread.exit                          # SEMANTIC: thread.exit guest-thread-lifecycle-v1
