# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Import the frozen S14 FileDescription body, bind its explicit endpoint
# dependency, and prove that all cursor verbs share one mutable description.
.data
filedesc_stream:
  # 64-byte state-stream header.
  .quad 0x4c4e503634444f4d
  .quad 1
  .quad 200
  .quad 1
  .quad 1000000000
  .quad 1
  .quad 0
  .quad 0
  # OBJECTS section header and one 120-byte container body.
  .quad 0x0000000100000008
  .quad 120
  .quad 1
  .quad 1
  .quad 0x000000010000000b
  .quad 88
  # FileDescription common prefix and S14 v1 fields.
  .quad 11
  .quad 0x0000000100000000
  .quad 64
  .quad 77
  .quad 0
  .quad 1
  .quad 0
  .quad 0
  # REBIND dependency 1, expected class ChannelEndpoint (2).
  .quad 1
  .quad 0x0000000200000002
  .quad 0

.text
  # Publish a record endpoint to discharge dependency 1.
  LI r2, 1
  channel.new r10, r2
  LI r3, 4
  channel.capacity r10, r10, r3
  channel.producer r10, r10, r0
  channel.consumer r10, r10, r0
  LI r3, 16
  channel.schema r10, r10, r3
  channel.acceptance r10, r10, r0
  channel.seal r11, r10

  LI r2, 11
  state.import r12, r2, r0, r0
  LI r13, filedesc_stream
  LI r14, 200
  WRITE r15, r12, r13, r14
  BNE r15, r14, bad
  LI r2, 1
  state.bind r15, r12, r2, r11
  BLE r15, r0, bad
  state.commit r16, r15
  BLE r16, r0, bad

  filedesc.cursor_get r17, r16          # SEMANTIC: filedesc.cursor_get guest-filedesc-cursor-v1
  LI r18, 77
  BNE r17, r18, bad
  LI r18, 100
  filedesc.cursor_set r17, r16, r18     # SEMANTIC: filedesc.cursor_set guest-filedesc-cursor-v1
  BNE r17, r18, bad
  LI r18, -25
  filedesc.cursor_add r17, r16, r18     # SEMANTIC: filedesc.cursor_add guest-filedesc-cursor-v1
  LI r18, 75
  BNE r17, r18, bad
  filedesc.cursor_get r17, r16
  BNE r17, r18, bad
  lifecycle.destroy r1, r16
  lifecycle.destroy r1, r11
  EXIT r0
bad:
  LI r1, 1
  EXIT r1
