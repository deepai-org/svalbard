# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
.text
  LI r1, 1
  FLI f1, 16
  FLI f2, 17
  FADD f3, f1, f2
  FSUB f3, f1, f2
  FMUL f3, f1, f2
  FDIV f3, f1, f2
  FSQRT f3, f1
  FMIN f3, f1, f2
  FMAX f3, f1, f2
  FMINM f3, f1, f2
  FMAXM f3, f1, f2
  FMADD f3, f1, f2, f1
  FMSUB f3, f1, f2, f1
  FNMADD f3, f1, f2, f1
  FNMSUB f3, f1, f2, f1
  FSGNJ f3, f1, f2
  FSGNJN f3, f1, f2
  FSGNJX f3, f1, f2
  FEQ r3, f1, f2
  FLT r3, f1, f2
  FLE r3, f1, f2
  FCLASS r3, f1
  FROUND.RNE f3, f1
  FSEL f3, r0, f1, f2, eq
  FMV.X.F.D r3, f1
  FMV.F.X.D f3, r1
  FCVT.W.D r3, f1
  FCVT.D.W f3, r1
  FCVT.S.D f3, f1
  EXIT r0
