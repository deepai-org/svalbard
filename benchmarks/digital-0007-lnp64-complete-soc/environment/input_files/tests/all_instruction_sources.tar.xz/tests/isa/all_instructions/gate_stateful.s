# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked CallGate builder, async submit, and synchronous crossing.
.data
msgdesc: .zero 56
completion: .zero 24
gate_pool: .zero 256

.text
  gate.new r10, r0                       # SEMANTIC: gate.new guest-callgate-v1
  LI r2, gate_entry
  gate.entry r10, r10, r2                # SEMANTIC: gate.entry guest-callgate-v1
  LI r2, gate_pool
  LI r3, 256
  LI r4, 1
  gate.stack r10, r10, r2, r3, r4        # SEMANTIC: gate.stack guest-callgate-v1
  LI r2, 64
  LI r3, 4
  LI r4, 4
  gate.limits r10, r10, r2, r3, r4       # SEMANTIC: gate.limits guest-callgate-v1
  LI r2, 100
  LI r3, 10
  gate.timing r10, r10, r2, r3, 0        # SEMANTIC: gate.timing guest-callgate-v1
  LI r2, 4
  LI r3, 5
  LI r4, 1
  gate.borrow_arg r10, r10, r2, r3, r4   # SEMANTIC: gate.borrow_arg guest-callgate-v1
  LI r2, 0
  gate.abi r10, r10, r2                   # SEMANTIC: gate.abi guest-callgate-v1
  gate.seal r11, r10                      # SEMANTIC: gate.seal guest-callgate-v1
  BLE r11, r0, bad

  # Async submit snapshots a null descriptor, allocates a nonzero ActivityRef,
  # and publishes one completion record into the reserved queue slot.
  LI r2, 4
  cqueue.new r12, r0, r2
  # Async submission carries the fixed seven-word descriptor even when every
  # byte/cap/borrow cardinality is zero.
  LI r4, msgdesc
  LI r5, 8
  LI r3, msgdesc
  gate.submit r13, r11, r12, r3           # SEMANTIC: gate.submit guest-callgate-v1
  BLE r13, r0, bad
  LI r3, completion
  cqueue.recv r14, r12, r3
  BNE r14, r0, bad
  LD r15, [r3, 0]
  BNE r15, r13, bad

  # Tail transfer without an existing continuation is malformed and leaves
  # control in the caller.  Its discriminator lives in fixed r3.
  GATE_TAIL r15, r11                     # SEMANTIC: gate_tail guest-gate-tail-malformed-v1
  LI r2, -4
  BNE r3, r2, bad

  # A null-descriptor synchronous crossing preserves the continuation, runs
  # the entry, and returns its value with terminal discriminator zero.
  LI r3, 0
  GATE_CALL r16, r11, r3                 # SEMANTIC: gate_call guest-gate-roundtrip-v1
  LI r2, 42
  BNE r16, r2, bad
  BNE r3, r0, bad

  gate.new r10, r0
  gate.abort r10                         # SEMANTIC: gate.abort guest-callgate-abort-v1
  cqueue.destroy r1, r12
  lifecycle.destroy r1, r11
  EXIT r0

gate_entry:
  # The engine-held continuation records call_rd, so the callee returns through
  # that same architectural register without being able to redirect the write.
  LI r16, 42
  GATE_RETURN r17, r0                    # SEMANTIC: gate_return guest-gate-roundtrip-v1
  # A successful gate return never falls through.
  LI r1, 1
  EXIT r1
bad:
  LI r1, 1
  EXIT r1
