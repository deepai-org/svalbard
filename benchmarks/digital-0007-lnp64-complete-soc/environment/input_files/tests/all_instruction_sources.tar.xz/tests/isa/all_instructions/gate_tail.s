# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
.text
  LI r1, 0
  GATE_TAIL r1, r1
  EXIT r0
