# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
#
# Dynamic reachability cases for non-control integer register and immediate
# instructions. Inputs avoid division by zero and undefined shift concerns.
.text
  LI r1, 0x1234
  LI r2, 7
  LI r3, -9

  ADD r4, r1, r2
  SUB r4, r1, r2
  MUL r4, r1, r2
  MULH r4, r1, r3
  MULHU r4, r1, r2
  DIV r4, r1, r2
  UDIV r4, r1, r2
  SREM r4, r1, r2
  UREM r4, r1, r2
  AND r4, r1, r2
  OR r4, r1, r2
  XOR r4, r1, r2
  ANDN r4, r1, r2
  ORN r4, r1, r2
  XNOR r4, r1, r2
  NOT r4, r1
  LSL r4, r1, r2
  LSR r4, r1, r2
  ASR r4, r3, r2
  ROL r4, r1, r2
  ROR r4, r1, r2
  SLT r4, r3, r2
  SLTU r4, r1, r2
  SEL.EQ r4, r0, r1, r2
  SH1ADD r4, r1, r2
  SH2ADD r4, r1, r2
  SH3ADD r4, r1, r2
  ADD3 r4, r1, r2, r3
  CARRY r4, r1, r2, r0
  OVADD r4, r1, r2
  OVSUB r4, r1, r2
  OVMUL r4, r1, r2
  OVMULU r4, r1, r2
  BEXT r4, r1, 0x0804
  BEXTS r4, r1, 0x0804
  BINS r4, r1, r2, 4, 8
  FSL r4, r1, r2, r3
  FSR r4, r1, r2, r3
  CLMUL r4, r1, r2
  CLMULH r4, r1, r2
  SEXT.B r4, r3
  SEXT.H r4, r3
  SEXT.W r4, r3
  ZEXT.B r4, r3
  ZEXT.H r4, r3
  ZEXT.W r4, r3
  CLZ r4, r1
  CTZ r4, r1
  POPCNT r4, r1
  BSWAP16 r4, r1
  BSWAP32 r4, r1
  BSWAP64 r4, r1
  MIN r4, r1, r3
  MAX r4, r1, r3
  MINU r4, r1, r2
  MAXU r4, r1, r2

  ADDI r4, r1, 5
  ANDI r4, r1, 0xff
  ORI r4, r1, 0x40
  XORI r4, r1, 0x40
  LSLI r4, r1, 3
  LSRI r4, r1, 3
  ASRI r4, r3, 3
  RORI r4, r1, 3
  SLTI r4, r3, 0
  SLTIU r4, r1, 0x2000
  LIU r4, r0, 0x12345
  AUIPC r4, 0
  ADDIW r4, r1, 5
  SLLIW r4, r1, 3
  SRLIW r4, r1, 3
  SRAIW r4, r3, 3
  RORIW r4, r1, 3
  SLLI.UW r4, r1, 3

  EXIT r0
