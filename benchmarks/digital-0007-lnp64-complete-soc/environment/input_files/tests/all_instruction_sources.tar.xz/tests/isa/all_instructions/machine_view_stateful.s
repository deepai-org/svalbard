# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Derive a restricted MachineView from the reset-granted physical view and
# prove every builder fact through the sealed view's raw getter surface.
.data
startup_record: .zero 2048

.text
  # Discover the delegated physical MachineView exactly as a runtime does;
  # neither its slot nor the capability-handle packing is a guest constant.
  LI r2, 16
  JAL r1, startup_find_class
  BEQ r2, r0, bad
  ADD r16, r2, r0

  # Read the physical limits used below, then mint the prospective child.
  LI r3, 0
  mview.get r20, r2, r3                 # SEMANTIC: mview.get guest-mview-derived-v1
  LI r3, 3
  mview.get r21, r2, r3
  LI r3, 4
  mview.get r22, r2, r3
  LI r3, 5
  mview.get r23, r2, r3
  LI r3, 6
  mview.get r24, r2, r3
  LI r3, 7
  mview.get r25, r2, r3
  LI r3, 8
  mview.get r26, r2, r3
  LI r3, 9
  mview.get r27, r2, r3
  LI r3, 10
  mview.get r28, r2, r3
  LI r3, 11
  mview.get r29, r2, r3

  mview.identity_scope r19, r2          # SEMANTIC: mview.identity_scope guest-mview-derived-v1
  mview.new r10, r2                     # SEMANTIC: mview.new guest-mview-derived-v1
  BLE r10, r0, bad

  # Tile zero is a proper, observable subset of the physical topology.
  snew r11
  LI r3, 0
  sadd r11, r11, r3
  mview.tiles r10, r10, r11             # SEMANTIC: mview.tiles guest-mview-derived-v1
  BLE r10, r0, bad

  LI r3, 0
  mview.features r10, r10, r3           # SEMANTIC: mview.features guest-mview-derived-v1
  BLE r10, r0, bad
  mview.counters r10, r10, r3           # SEMANTIC: mview.counters guest-mview-derived-v1
  BLE r10, r0, bad
  mview.identity r10, r10, r19          # SEMANTIC: mview.identity guest-mview-derived-v1
  BLE r10, r0, bad

  LI r3, 17
  mview.time r10, r10, r3, r21          # SEMANTIC: mview.time guest-mview-derived-v1
  BLE r10, r0, bad
  LI r3, 47
  mview.va_width r10, r10, r3           # SEMANTIC: mview.va_width guest-mview-derived-v1
  BLE r10, r0, bad
  mview.atomic_agents r10, r10, r22     # SEMANTIC: mview.atomic_agents guest-mview-derived-v1
  BLE r10, r0, bad
  mview.gate_inline_limit r10, r10, r23 # SEMANTIC: mview.gate_inline_limit guest-mview-derived-v1
  BLE r10, r0, bad
  mview.iovec_limit r10, r10, r24       # SEMANTIC: mview.iovec_limit guest-mview-derived-v1
  BLE r10, r0, bad
  mview.sgl_limit r10, r10, r25         # SEMANTIC: mview.sgl_limit guest-mview-derived-v1
  BLE r10, r0, bad
  mview.workqueue_limits r10, r10, r27, r26 # SEMANTIC: mview.workqueue_limits guest-mview-derived-v1
  BLE r10, r0, bad
  mview.invalidation_bound r10, r10, r28, r29 # SEMANTIC: mview.invalidation_bound guest-mview-derived-v1
  BLE r10, r0, bad

  mview.seal r12, r10                   # SEMANTIC: mview.seal guest-mview-derived-v1
  BLE r12, r0, bad
  LI r3, 0
  mview.get r13, r12, r3
  LI r4, 47
  BNE r13, r4, bad
  LI r3, 1
  mview.get r13, r12, r3
  LI r4, 1
  BNE r13, r4, bad
  LI r3, 3
  mview.get r13, r12, r3
  BNE r13, r21, bad
  LI r3, 4
  mview.get r13, r12, r3
  BNE r13, r22, bad
  LI r3, 8
  mview.get r13, r12, r3
  BNE r13, r26, bad
  LI r3, 9
  mview.get r13, r12, r3
  BNE r13, r27, bad
  LI r3, 10
  mview.get r13, r12, r3
  BNE r13, r28, bad
  LI r3, 11
  mview.get r13, r12, r3
  BNE r13, r29, bad

  # Abort is independently checked on a fresh current builder.
  mview.new r10, r16
  mview.abort r10                       # SEMANTIC: mview.abort guest-mview-abort-v1
  # Cursor-handle allocation legitimately differs with reset endowments;
  # publish only profile-independent architectural results.
  LI r3, 0
  LI r4, 0
  LI r5, 0
  EXIT r0

# r2 = object class in, capability handle out; r3-r9 clobbered.
startup_find_class:
  ADD r8, r2, r0
  LI r3, 4
  denum.begin r5, r0, r3
  BLE r5, r0, startup_find_miss
  LI r3, startup_record
startup_find_loop:
  cursor.next r6, r5, r3
  BNE r6, r0, startup_find_miss_close
  LW r7, [r3, 8]
  BEQ r7, r8, startup_find_hit
  JMP startup_find_loop
startup_find_hit:
  LD r2, [r3, 0]
  cursor.end r5
  RET
startup_find_miss_close:
  cursor.end r5
startup_find_miss:
  LI r2, 0
  RET
bad:
  LI r1, 1
  EXIT r1
