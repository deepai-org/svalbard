# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
.data
memory_area: .quad 0x78776655ff008080
             .quad 0x1112131415161718
scratch:     .quad 0
             .quad 0
expected_a:  .quad 0x78776655ff008080
expected_b:  .quad 0x1112131415161718
store_a:     .quad 0x7f0123456789abcd
store_b:     .quad 0x1020304050607080
store_c:     .quad 0x0123456789abcdef
expected_w:  .quad 0x00000000ff008080

.text
  LI r1, memory_area
  LI r10, scratch

  LB r4, [r1, 0]                    # SEMANTIC: lb guest-memory-transition-v1
  LI r5, -128
  BNE r4, r5, bad
  LBU r4, [r1, 0]                   # SEMANTIC: lbu guest-memory-transition-v1
  LI r5, 128
  BNE r4, r5, bad
  LH r4, [r1, 0]                    # SEMANTIC: lh guest-memory-transition-v1
  LI r5, -32640
  BNE r4, r5, bad
  LHU r4, [r1, 0]                  # SEMANTIC: lhu guest-memory-transition-v1
  LI r5, 0x8080
  BNE r4, r5, bad
  LW r4, [r1, 0]                   # SEMANTIC: lw guest-memory-transition-v1
  LI r5, -16744320
  BNE r4, r5, bad
  LWU r4, [r1, 0]                  # SEMANTIC: lwu guest-memory-transition-v1
  LI r5, expected_w
  LD r5, [r5, 0]
  BNE r4, r5, bad
  LD r4, [r1, 0]                   # SEMANTIC: ld guest-memory-transition-v1
  LI r5, expected_a
  LD r5, [r5, 0]
  BNE r4, r5, bad

  LI r2, 0x7f
  ST.B [r10, 0], r2                # SEMANTIC: sb guest-memory-transition-v1
  LBU r4, [r10, 0]
  BNE r4, r2, bad
  LI r2, 0x7f01
  ST.H [r10, 0], r2                # SEMANTIC: sh guest-memory-transition-v1
  LHU r4, [r10, 0]
  BNE r4, r2, bad
  LI r2, 0x7f012345
  ST.W [r10, 0], r2                # SEMANTIC: sw guest-memory-transition-v1
  LWU r4, [r10, 0]
  BNE r4, r2, bad
  LI r2, store_a
  LD r2, [r2, 0]
  ST [r10, 0], r2                  # SEMANTIC: sd guest-memory-transition-v1
  LD r4, [r10, 0]
  BNE r4, r2, bad

  LI r3, 1
  LDX.W r4, r1, r3, 3             # SEMANTIC: ldx guest-memory-transition-v1
  LI r5, 0x15161718
  BNE r4, r5, bad
  LI r2, store_b
  LD r2, [r2, 0]
  STX.D r2, r10, r3, 3            # SEMANTIC: stx guest-memory-transition-v1
  LD r4, [r10, 8]
  BNE r4, r2, bad

  LD.AQ.D r4, 0(r1)                # SEMANTIC: ld.aq guest-memory-transition-v1
  LI r5, expected_a
  LD r5, [r5, 0]
  BNE r4, r5, bad
  LI r2, store_c
  LD r2, [r2, 0]
  SD.RL.D 0(r10), r2               # SEMANTIC: sd.rl guest-memory-transition-v1
  LD r4, [r10, 0]
  BNE r4, r2, bad

  LDP r4, 0(r1)                    # SEMANTIC: ldp guest-memory-transition-v1
  LI r6, expected_a
  LD r6, [r6, 0]
  BNE r4, r6, bad
  LI r6, expected_b
  LD r6, [r6, 0]
  BNE r5, r6, bad
  SDP r4, 0(r10)                   # SEMANTIC: sdp guest-memory-transition-v1
  LD r6, [r10, 0]
  BNE r6, r4, bad
  LD r6, [r10, 8]
  BNE r6, r5, bad
  LD.Q.AQ r4, 0(r1)                # SEMANTIC: ld.q guest-memory-transition-v1
  LI r6, expected_a
  LD r6, [r6, 0]
  BNE r4, r6, bad
  LI r6, expected_b
  LD r6, [r6, 0]
  BNE r5, r6, bad
  SD.Q.AQRL 0(r10), r4             # SEMANTIC: sd.q guest-memory-transition-v1
  LD r6, [r10, 0]
  BNE r6, r4, bad
  LD r6, [r10, 8]
  BNE r6, r5, bad

  PREFETCH r1, 0, read, 0          # SEMANTIC: prefetch guest-nonfaulting-hint-v1

  FLW f2, 0(r1)                    # SEMANTIC: flw guest-fp-memory-transition-v1
  FSW 0(r10), f2
  LWU r6, [r10, 0]
  LI r7, expected_w
  LD r7, [r7, 0]
  BNE r6, r7, bad
  FLD f2, 0(r1)                    # SEMANTIC: fld guest-fp-memory-transition-v1
  FSD 0(r10), f2
  LD r6, [r10, 0]
  LI r7, expected_a
  LD r7, [r7, 0]
  BNE r6, r7, bad
  FLH f2, 0(r1)                    # SEMANTIC: flh guest-fp-memory-transition-v1
  FSH 0(r10), f2
  LHU r6, [r10, 0]
  LI r7, 0x8080
  BNE r6, r7, bad
  FLD.Q f2, 0(r1)                  # SEMANTIC: fld.q guest-fp-memory-transition-v1
  FSD.Q 0(r10), f2
  LD r6, [r10, 0]
  LI r7, expected_a
  LD r7, [r7, 0]
  BNE r6, r7, bad
  LD r6, [r10, 8]
  LI r7, expected_b
  LD r7, [r7, 0]
  BNE r6, r7, bad

  FSW 0(r10), f2                   # SEMANTIC: fsw guest-fp-memory-transition-v1
  LWU r6, [r10, 0]
  LI r7, expected_w
  LD r7, [r7, 0]
  BNE r6, r7, bad
  FSD 0(r10), f2                   # SEMANTIC: fsd guest-fp-memory-transition-v1
  LD r6, [r10, 0]
  LI r7, expected_a
  LD r7, [r7, 0]
  BNE r6, r7, bad
  FSH 0(r10), f2                   # SEMANTIC: fsh guest-fp-memory-transition-v1
  LHU r6, [r10, 0]
  LI r7, 0x8080
  BNE r6, r7, bad
  FSD.Q 0(r10), f2                 # SEMANTIC: fsd.q guest-fp-memory-transition-v1
  LD r6, [r10, 0]
  LI r7, expected_a
  LD r7, [r7, 0]
  BNE r6, r7, bad
  LD r6, [r10, 8]
  LI r7, expected_b
  LD r7, [r7, 0]
  BNE r6, r7, bad

  EXIT r0
bad:
  LI r1, 1
  EXIT r1
