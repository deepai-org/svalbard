# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked state-stream round trip and observation cursors.
.data
stream_bytes: .zero 1024
cursor_record: .zero 128

.text
  LI r2, 0
  LI r3, 0x1234
  counter.new r10, r2, r3

  # Standalone Counter state round-trips through ordinary stream I/O.  Import
  # publishes nothing until commit, and the imported value is observationally
  # identical under the class's raw getter.
  LI r2, 0
  state.open r11, r10, r2, r0          # SEMANTIC: state.open guest-state-roundtrip-v1
  BLE r11, r0, bad
  LI r12, stream_bytes
  LI r13, 1024
  READ r14, r11, r12, r13
  BLE r14, r0, bad
  LI r2, 3
  LI r3, 0                              # implicit self-capability, never raw DOMAIN_ID
  LI r4, 0
  state.import r15, r2, r3, r4         # SEMANTIC: state.import guest-state-roundtrip-v1
  BLE r15, r0, bad
  WRITE r16, r15, r12, r14
  BNE r16, r14, bad
  state.commit r17, r15                # SEMANTIC: state.commit guest-state-roundtrip-v1
  BLE r17, r0, bad
  counter.read r18, r17
  LI r2, 0x1234
  BNE r18, r2, bad

  # A dependency bind against a stream with no REBIND dependency is malformed
  # and leaves the import builder current for explicit destruction.
  LI r3, 0
  LI r2, 3
  state.import r15, r2, r3, r0
  LI r4, 1
  state.bind r19, r15, r4, r10         # SEMANTIC: state.bind guest-state-bind-malformed-v1
  LI r5, -4
  BNE r19, r5, bad
  lifecycle.destroy r1, r15

  # Domain enumeration of live threads writes one frozen, versioned record.
  LI r2, 2
  denum.begin r20, r0, r2              # SEMANTIC: denum.begin guest-domain-enum-v1
  BLE r20, r0, bad
  LI r3, cursor_record
  cursor.next r19, r20, r3
  BNE r19, r0, bad
  cursor.end r20

  # Object enumeration exposes stable Waitset member identity and cookie.
  waitset.new r21
  LI r2, 0x55
  waitset.add r22, r21, r10, r2, r3, r4
  LI r2, 0
  objenum.begin r20, r21, r2           # SEMANTIC: objenum.begin guest-object-enum-v1
  BLE r20, r0, bad
  cursor.next r19, r20, r3
  BNE r19, r0, bad
  LD r23, [r3, 8]
  BNE r23, r22, bad
  cursor.end r20

  # A mapping-class mark and cursor use the same generation cut.  The current
  # flat image has mappings, so the first VMA record must be available.
  LI r2, 2
  observe.mark r24, r0, r2             # SEMANTIC: observe.mark guest-observe-generation-v1
  BLE r24, r0, bad
  LI r2, 1
  changes.begin r20, r0, r24, r2       # SEMANTIC: changes.begin guest-observe-generation-v1
  BLE r20, r0, bad
  cursor.next r19, r20, r3
  BNE r19, r0, bad
  cursor.end r20

  # No component has produced a MemoryIncident, so begin returns an empty
  # cursor.  Ack remains idempotent by stable nonzero incident id.
  incident.begin r20, r0, r0           # SEMANTIC: incident.begin guest-incident-empty-v1
  BLE r20, r0, bad
  cursor.next r19, r20, r3
  LI r2, -17
  BNE r19, r2, bad
  cursor.end r20
  LI r2, 1
  incident.ack r19, r0, r2             # SEMANTIC: incident.ack guest-incident-ack-v1
  BNE r19, r0, bad
  incident.bind r19, r0, r0            # SEMANTIC: incident.bind guest-incident-bind-badref-v1
  LI r2, -2
  BNE r19, r2, bad

  # The typed mmap alias creates an anonymous mapping with the requested
  # protection and returns its address; canonical unmap removes it.
  LI r2, 0
  LI r3, 4096
  LI r4, 3
  mmap r25, r0, r2, r3, r4             # SEMANTIC: mmap guest-typed-mmap-v1
  BLE r25, r0, bad
  LI r4, 0x403
  MEM_GRANT r26, r25, r3, r4            # SEMANTIC: mem_grant guest-memory-grant-v1
  BLE r26, r0, bad
  cap.rights r27, r26
  BNE r27, r4, bad
  cap.revoke r19, r26
  BNE r19, r0, bad
  munmap_range r19, r25, r3
  BNE r19, r0, bad

  waitset.destroy r1, r21
  counter.destroy r1, r17
  counter.destroy r1, r10
  EXIT r0
bad:
  LI r1, 1
  EXIT r1
