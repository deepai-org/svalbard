# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
.data
futex_a: .quad 1
futex_b: .quad 0

.text
  LI r1, futex_a
  LI r2, futex_b
  LI r3, 2
  LI r4, 1
  LI r5, 0

  FENCE                             # SEMANTIC: fence guest-ordering-sequence-v1
  FENCE.ACQ                         # SEMANTIC: fence.acq guest-ordering-sequence-v1
  FENCE.REL                         # SEMANTIC: fence.rel guest-ordering-sequence-v1
  FENCE.ACQ_REL                     # SEMANTIC: fence.acq_rel guest-ordering-sequence-v1
  FENCE.SC                          # SEMANTIC: fence.sc guest-ordering-sequence-v1
  ISYNC r6, r1, r4                  # SEMANTIC: isync guest-sync-result-v1
  BNE r6, r0, bad
  PAUSE                             # SEMANTIC: pause guest-nonfaulting-hint-v1
  FUTEX_WAKE r6, r1, r4             # SEMANTIC: futex_wake guest-futex-result-v1
  BNE r6, r0, bad
  FUTEX_REQUEUE r6, r1, r2, r4, r4, r5 # SEMANTIC: futex_requeue guest-futex-result-v1
  BNE r6, r0, bad
  # The memory word is 1 while expected is 2, so this reaches FUTEX_WAIT and
  # returns immediately instead of parking the single-thread test.
  FUTEX_WAIT r6, r1, r3, r5         # SEMANTIC: futex_wait guest-futex-result-v1
  LI r7, -14
  BNE r6, r7, bad
  EXIT r0
bad:
  LI r1, 1
  EXIT r1
