# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
.data
scratch: .quad 0
         .quad 0

.text
  LI r1, 0
  LI r2, scratch
  LI r3, 8
  LI r4, 0

  GATE_CALL r5, r1, r2
  SEND r5, r1, r2
  RECV r5, r1, r2
  READ r5, r1, r2, r3
  WRITE r5, r1, r2, r3
  READV r5, r1, r2, r3
  WRITEV r5, r1, r2, r3
  READV_AT r5, r1, r2, r3, r4
  WRITEV_AT r5, r1, r2, r3, r4
  WAIT r5, r1, r4
  MEM_GRANT r5, r1, r2, r3
  MAP.PROTECT r5, r1, r2, r3
  MUNMAP_RANGE r5, r2, r3
  MAP.DEMOTE r5, r2, r3
  GET_PCR r5, DOMAIN_ID
  SET_PCR r5, EVENTMASK, r4
  ENV_OPEN r5, r4
  RANDOM r5, r2, r3
  EXIT r0

