# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
.data
payload:    .quad 0x1122334455667788
recv_buf:   .quad 0
random_buf: .zero 16
send_desc:  .zero 32
recv_desc:  .zero 32
write_iov:  .zero 16
read_iov:   .zero 16
ring_storage: .zero 96
ready_record: .zero 24

.text
  GET_PCR r1, DOMAIN_ID              # SEMANTIC: get_pcr guest-pcr-roundtrip-v1
  BEQ r1, r0, bad
  LI r2, 0x55
  SET_PCR r3, EVENTMASK, r2          # SEMANTIC: set_pcr guest-pcr-roundtrip-v1
  GET_PCR r4, EVENTMASK
  BNE r4, r2, bad

  ENV_OPEN r5, r0                    # SEMANTIC: env_open guest-environment-stream-v1
  BEQ r5, r0, bad
  # The allocated stream handle may differ because profiles enumerate
  # different startup devices; normalize it after proving it is valid.
  LI r5, 1
  LI r6, random_buf
  LI r7, 16
  RANDOM r8, r6, r7                  # SEMANTIC: random guest-random-fill-v1
  BNE r8, r7, bad

  # Record endpoint and descriptor-based send/receive.
  LI r9, 1
  channel.new r10, r9
  LI r11, 8
  channel.capacity r10, r10, r11
  channel.producer r10, r10, r0
  channel.consumer r10, r10, r0
  channel.acceptance r10, r10, r0
  channel.seal r12, r10
  LI r13, send_desc
  LI r14, payload
  ST [r13, 0], r14
  ST [r13, 8], r11
  ST [r13, 16], r0
  ST [r13, 24], r0
  SEND r15, r12, r13                # SEMANTIC: send guest-record-ipc-roundtrip-v1
  BNE r15, r11, bad
  LI r16, recv_desc
  LI r17, recv_buf
  ST [r16, 0], r17
  ST [r16, 8], r11
  ST [r16, 16], r0
  ST [r16, 24], r0
  RECV r15, r12, r16                # SEMANTIC: recv guest-record-ipc-roundtrip-v1
  BNE r15, r11, bad
  LD r18, [r14, 0]
  LD r19, [r17, 0]
  BNE r18, r19, bad
  lifecycle.destroy r15, r12
  BNE r15, r0, bad

  # Byte endpoint supports ordinary and vectored transfers.
  channel.new r10, r0
  LI r11, 64
  channel.capacity r10, r10, r11
  channel.producer r10, r10, r0
  channel.consumer r10, r10, r0
  channel.acceptance r10, r10, r0
  channel.seal r12, r10
  LI r7, 8
  WRITE r15, r12, r14, r7           # SEMANTIC: write guest-byte-io-roundtrip-v1
  BNE r15, r7, bad
  READ r15, r12, r17, r7            # SEMANTIC: read guest-byte-io-roundtrip-v1
  BNE r15, r7, bad
  LD r18, [r14, 0]
  LD r19, [r17, 0]
  BNE r18, r19, bad

  LI r20, write_iov
  ST [r20, 0], r14
  ST [r20, 8], r7
  WRITEV r15, r12, r20, r9          # SEMANTIC: writev guest-vectored-io-roundtrip-v1
  BNE r15, r7, bad
  LI r21, read_iov
  ST [r21, 0], r17
  ST [r21, 8], r7
  READV r15, r12, r21, r9           # SEMANTIC: readv guest-vectored-io-roundtrip-v1
  BNE r15, r7, bad
  LD r18, [r14, 0]
  LD r19, [r17, 0]
  BNE r18, r19, bad
  # Positioned I/O is deliberately unsupported on a non-seekable byte
  # endpoint; both forms must report the architectural condition, not leak a
  # host ESPIPE number into the result channel.
  READV_AT r15, r12, r21, r9, r0    # SEMANTIC: readv_at guest-positioned-nonseekable-v1
  LI r22, -5
  BNE r15, r22, bad
  WRITEV_AT r15, r12, r20, r9, r0   # SEMANTIC: writev_at guest-positioned-nonseekable-v1
  BNE r15, r22, bad
  lifecycle.destroy r15, r12
  BNE r15, r0, bad

  # A threshold-ready Counter is immediately observable through WAIT.
  counter.new r22, r0, r9
  counter.threshold r15, r22, r9
  waitset.new r23
  LI r24, 1
  LI r21, 0x99
  LI r27, 0
  waitset.add r25, r23, r22, r24, r21, r27
  LI r28, 4096
  backing.new r30, r28, r0
  backing.seal r30, r30
  map.new r28, r30, r0, r28
  map.private r28, r28
  LI r29, 0x30000
  map.at r28, r28, r29
  LI r29, 3
  map.protection r28, r28, r29
  map.seal r28, r28
  LI r29, 4
  eventring.new r30, r28, r29       # SEMANTIC: eventring.new guest-ready-waitset-v1
  eventring.bind r15, r23, r30      # SEMANTIC: eventring.bind guest-ready-waitset-v1
  BNE r15, r0, bad
  WAIT r26, r23, r0                 # SEMANTIC: wait guest-ready-waitset-v1
  LI r27, 1
  BNE r26, r27, bad
  LI r28, ready_record
  ready.next r15, r30, r28          # SEMANTIC: ready.next guest-ready-waitset-v1
  BNE r15, r0, bad
  LD r29, [r28, 0]
  BNE r29, r25, bad
  LD r29, [r28, 8]
  BNE r29, r21, bad
  LD r29, [r28, 16]
  BNE r29, r24, bad
  eventring.destroy r15, r30        # SEMANTIC: eventring.destroy guest-ready-waitset-v1
  BNE r15, r0, bad
  waitset.destroy r15, r23
  counter.destroy r15, r22

  EXIT r0
bad:
  LI r1, 1
  EXIT r1
