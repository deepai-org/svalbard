# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked Timer delivery relations and absolute clock bases.
.text
  clock.new r10, r0
  LI r2, 0
  LI r3, 9
  counter.new r11, r2, r3
  LI r2, 4
  cqueue.new r12, r0, r2

  # Counter delivery seals only when the relation has the expected class.
  timer.new r13, r0
  timer.clock r13, r13, r0              # SEMANTIC: timer.clock guest-bound-clock-sentinel-v1
  timer.delivery_counter r13, r13, r11  # SEMANTIC: timer.delivery_counter guest-timer-delivery-v1
  timer.seal r14, r13
  BLE r14, r0, bad
  timer.destroy r1, r14

  # CompletionQueue delivery is another typed relation, not an enum mode.
  timer.new r13, r0
  timer.clock r13, r13, r10
  timer.delivery_queue r13, r13, r12    # SEMANTIC: timer.delivery_queue guest-timer-delivery-v1
  timer.seal r14, r13
  BLE r14, r0, bad
  timer.destroy r1, r14

  # Construct a record endpoint for message delivery.
  LI r2, 1
  channel.new r15, r2
  LI r3, 4
  channel.capacity r15, r15, r3
  channel.producer r15, r15, r0
  channel.consumer r15, r15, r0
  LI r3, 16
  channel.schema r15, r15, r3
  channel.acceptance r15, r15, r0
  channel.seal r16, r15
  timer.new r13, r0
  timer.clock r13, r13, r10
  timer.delivery_message r13, r13, r16  # SEMANTIC: timer.delivery_message guest-timer-delivery-v1
  timer.seal r14, r13
  BLE r14, r0, bad
  timer.destroy r1, r14

  # Gate delivery is a valid builder fact, but the emulator has no detached
  # activation fixture in this program; sealing reports the specified BUSY
  # admission boundary rather than silently choosing another delivery path.
  gate.new r17, r0
  LI r2, gate_stub
  gate.entry r17, r17, r2
  LI r2, 0x70000
  LI r3, 4096
  LI r4, 1
  gate.stack r17, r17, r2, r3, r4
  gate.abi r17, r17, r0
  gate.seal r18, r17
  timer.new r13, r0
  timer.clock r13, r13, r10
  timer.delivery_gate r13, r13, r18     # SEMANTIC: timer.delivery_gate guest-timer-delivery-v1
  timer.seal r14, r13
  LI r2, -14
  BNE r14, r2, bad
  timer.abort r13                       # SEMANTIC: timer.abort guest-timer-abort-v1

  # Realtime binds the reservation domain (`0 = self`) and placement uses the
  # view-relative default tile spelling.  Both facts survive generation
  # threading and can be discarded with the unpublished builder.
  timer.new r13, r0
  timer.realtime r13, r13, r0           # SEMANTIC: timer.realtime guest-timer-builder-v1
  LI r2, -1
  timer.place r13, r13, r2              # SEMANTIC: timer.place guest-timer-builder-v1
  timer.abort r13

  # Absolute-view and physical deadlines mint distinct arm identities and
  # remain disarmable through the one canonical transition.
  timer.new r13, r0
  timer.clock r13, r13, r10
  LI r2, 3
  timer.delivery_event r13, r13, r2
  timer.seal r14, r13
  LI r2, 1000000
  timer.arm_abs r19, r14, r2, r0, 0     # SEMANTIC: timer.arm_abs guest-timer-absolute-v1
  BLE r19, r0, bad
  timer.disarm r1, r14
  timer.arm_phys r20, r14, r2, r0, 0    # SEMANTIC: timer.arm_phys guest-timer-absolute-v1
  BLE r20, r19, bad
  timer.destroy r1, r14

  lifecycle.destroy r1, r18
  lifecycle.destroy r1, r16
  cqueue.destroy r1, r12
  counter.destroy r1, r11
  clock.destroy r1, r10
  EXIT r0

gate_stub:
  GATE_RETURN r1, r0
bad:
  LI r1, 1
  EXIT r1
