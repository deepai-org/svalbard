# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Semantic validation for the newest typed operations.  These deliberately
# exercise architected validation before any state mutation: absent activation
# windows, stale thread identity, and wrong-class/null capabilities must return
# their precise conditions rather than being accepted or decoded as reserved.
.text
  LI r2, 256
  cap.mint_service r10, r2, r0, r0 # SEMANTIC: cap.mint_service guest-service-mint-authority-v1
  LI r3, -4
  BNE r10, r3, bad

  acopy.in r11, r0, r0, r0, r0    # SEMANTIC: acopy.in guest-activation-window-validation-v1
  LI r3, -2
  BNE r11, r3, bad
  acopy.out r12, r0, r0, r0, r0   # SEMANTIC: acopy.out guest-activation-window-validation-v1
  BNE r12, r3, bad
  acopy.instr r13, r0, r0, r0, r0 # SEMANTIC: acopy.instr guest-activation-window-validation-v1
  BNE r13, r3, bad
  acopy.outstr r14, r0, r0, r0, r0 # SEMANTIC: acopy.outstr guest-activation-window-validation-v1
  BNE r14, r3, bad

  # The positive generation-qualified transition is asserted independently in
  # domain_exec_stateful.s; retain this stale-target validation as a companion.
  thread.group r15, r0, r0, r0, r0
  LI r3, -3
  BNE r15, r3, bad

  gate.lifecycle_queue r16, r0, r0 # SEMANTIC: gate.lifecycle_queue guest-gate-builder-validation-v1
  LI r3, -9
  BNE r16, r3, bad
  gate.serve r17, r0, r0           # SEMANTIC: gate.serve guest-gate-serve-validation-v1
  LI r3, -2
  BNE r17, r3, bad

  backing.respond r18, r0, r0, r0, r0 # SEMANTIC: backing.respond guest-request-response-validation-v1
  LI r3, -9
  BNE r18, r3, bad

  EXIT r0
bad:
  LI r1, 1
  EXIT r1
