# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Positive, guest-checked lifecycles for typed ISA families.
.data
empty_msgdesc: .quad 0
               .quad 0
completion_record: .quad 0
                   .quad 0
debug_context: .zero 1200
debug_source:  .quad 0x12345678
debug_dest:    .quad 0
                   .quad 0
               .quad 0
               .quad 0
startup_record: .zero 2048

.text
  # Counter: create, observe, mutate, saturate, configure readiness, destroy.
  LI r2, 0
  LI r3, 10
  counter.new r1, r2, r3             # SEMANTIC: counter.new guest-counter-lifecycle-v1
  counter.read r4, r1                # SEMANTIC: counter.read guest-counter-lifecycle-v1
  BNE r4, r3, bad
  LI r5, 22
  counter.set r6, r1, r5             # SEMANTIC: counter.set guest-counter-lifecycle-v1
  BNE r6, r0, bad
  LI r7, -2
  counter.add r6, r1, r7             # SEMANTIC: counter.add guest-counter-lifecycle-v1
  BNE r6, r0, bad
  counter.read r4, r1
  LI r5, 20
  BNE r4, r5, bad
  counter.threshold r6, r1, r5       # SEMANTIC: counter.threshold guest-counter-lifecycle-v1
  BNE r6, r0, bad

  # Capability operations preserve referent identity while changing entries.
  cap.rights r26, r1                 # SEMANTIC: cap.rights guest-capability-lifecycle-v1
  BEQ r26, r0, bad
  cap.class r27, r28, r1             # SEMANTIC: cap.class guest-capability-lifecycle-v1
  LI r29, 3
  BNE r27, r29, bad
  cap.lineage r27, r28, r1           # SEMANTIC: cap.lineage guest-capability-lifecycle-v1
  BEQ r27, r0, bad
  cap.copy r25, r1, r26              # SEMANTIC: cap.copy guest-capability-lifecycle-v1
  BEQ r25, r0, bad
  cap.seal r29, r25                  # SEMANTIC: cap.seal guest-capability-lifecycle-v1
  BEQ r29, r0, bad
  cap.narrow r30, r25, r26           # SEMANTIC: cap.narrow guest-capability-lifecycle-v1
  BEQ r30, r0, bad
  cap.drop r6, r25                   # SEMANTIC: cap.drop guest-capability-lifecycle-v1
  BNE r6, r0, bad
  cap.drop r6, r29
  BNE r6, r0, bad
  cap.drop r6, r30
  BNE r6, r0, bad

  # Waitset membership returns a stable nonzero id and accepts modification.
  waitset.new r8                     # SEMANTIC: waitset.new guest-waitset-lifecycle-v1
  LI r9, 1
  # Six-slot typed calls carry their fifth and sixth source slots in the
  # architecturally fixed r4/r5 positions.
  LI r4, 0x1234
  LI r5, 0
  waitset.add r10, r8, r1, r9, r4, r5 # SEMANTIC: waitset.add guest-waitset-lifecycle-v1
  BEQ r10, r0, bad
  waitset.mod r6, r8, r10, r9, r4, r5 # SEMANTIC: waitset.mod guest-waitset-lifecycle-v1
  BNE r6, r0, bad
  waitset.del r6, r8, r10            # SEMANTIC: waitset.del guest-waitset-lifecycle-v1
  BNE r6, r0, bad
  waitset.destroy r6, r8             # SEMANTIC: waitset.destroy guest-waitset-lifecycle-v1
  BNE r6, r0, bad

  counter.destroy r6, r1             # SEMANTIC: counter.destroy guest-counter-lifecycle-v1
  BNE r6, r0, bad

  # Timer builder and live arm lifecycle with event delivery.
  clock.new r18, r0                   # SEMANTIC: clock.new guest-clock-lifecycle-v1
  clock.get r19, r18, r0              # SEMANTIC: clock.get guest-clock-lifecycle-v1
  clock.adjust r6, r18, r0            # SEMANTIC: clock.adjust guest-clock-lifecycle-v1
  BNE r6, r0, bad
  LI r2, 123
  clock.set r6, r18, r2               # SEMANTIC: clock.set guest-clock-lifecycle-v1
  BNE r6, r0, bad
  LI r3, 1
  clock.get r19, r18, r3
  BNE r19, r2, bad
  timer.new r11, r0                  # SEMANTIC: timer.new guest-timer-lifecycle-v1
  timer.clock r11, r11, r18          # SEMANTIC: timer.clock guest-timer-lifecycle-v1
  LI r12, 7
  timer.delivery_event r11, r11, r12 # SEMANTIC: timer.delivery_event guest-timer-lifecycle-v1
  timer.seal r13, r11                # SEMANTIC: timer.seal guest-timer-lifecycle-v1
  LI r14, 1000000
  timer.arm_rel r15, r13, r14, r0, 0 # SEMANTIC: timer.arm_rel guest-timer-lifecycle-v1
  BEQ r15, r0, bad
  timer.gettime r16, r13             # SEMANTIC: timer.gettime guest-timer-lifecycle-v1
  BEQ r16, r0, bad
  timer.disarm r17, r13              # SEMANTIC: timer.disarm guest-timer-lifecycle-v1
  BEQ r17, r0, bad
  timer.gettime r16, r13
  BNE r16, r0, bad
  timer.getoverrun r16, r13           # SEMANTIC: timer.getoverrun guest-timer-lifecycle-v1
  BNE r16, r0, bad
  timer.destroy r6, r13              # SEMANTIC: timer.destroy guest-timer-lifecycle-v1
  BNE r6, r0, bad
  clock.destroy r6, r18              # SEMANTIC: clock.destroy guest-clock-lifecycle-v1
  BNE r6, r0, bad

  # Record channel builder and live endpoint observability.
  LI r2, 1
  channel.new r20, r2                # SEMANTIC: channel.new guest-channel-lifecycle-v1
  LI r3, 8
  channel.capacity r20, r20, r3      # SEMANTIC: channel.capacity guest-channel-lifecycle-v1
  LI r4, 1
  channel.overrun r20, r20, r4       # SEMANTIC: channel.overrun guest-channel-lifecycle-v1
  channel.producer r20, r20, r0      # SEMANTIC: channel.producer guest-channel-lifecycle-v1
  channel.consumer r20, r20, r0      # SEMANTIC: channel.consumer guest-channel-lifecycle-v1
  LI r5, 24
  channel.schema r20, r20, r5        # SEMANTIC: channel.schema guest-channel-lifecycle-v1
  channel.acceptance r20, r20, r0    # SEMANTIC: channel.acceptance guest-channel-lifecycle-v1
  channel.seal r21, r20              # SEMANTIC: channel.seal guest-channel-lifecycle-v1
  channel.get r22, r21               # SEMANTIC: channel.get guest-channel-lifecycle-v1
  BNE r22, r3, bad
  channel.sent_records r22, r21      # SEMANTIC: channel.sent_records guest-channel-lifecycle-v1
  BNE r22, r0, bad
  channel.sent_bytes r22, r21        # SEMANTIC: channel.sent_bytes guest-channel-lifecycle-v1
  BNE r22, r0, bad
  channel.received_records r22, r21  # SEMANTIC: channel.received_records guest-channel-lifecycle-v1
  BNE r22, r0, bad
  channel.received_bytes r22, r21    # SEMANTIC: channel.received_bytes guest-channel-lifecycle-v1
  BNE r22, r0, bad
  channel.take_loss r22, r21         # SEMANTIC: channel.take_loss guest-channel-lifecycle-v1
  BNE r22, r0, bad
  LI r3, 16
  channel.resize r22, r21, r3        # SEMANTIC: channel.resize guest-channel-lifecycle-v1
  BNE r22, r0, bad
  channel.get r22, r21
  BNE r22, r3, bad
  channel.set_blocking r22, r21, r4  # SEMANTIC: channel.set_blocking guest-channel-lifecycle-v1
  BNE r22, r0, bad
  LI r3, 2
  channel.shutdown r22, r21, r3      # SEMANTIC: channel.shutdown guest-channel-lifecycle-v1
  BNE r22, r0, bad
  lifecycle.destroy r22, r21
  BNE r22, r0, bad

  channel.new r20, r2
  channel.abort r20                  # SEMANTIC: channel.abort guest-channel-abort-v1

  # Immutable set algebra: B is a subset of A; union/intersection preserve it.
  snew r1                            # SEMANTIC: snew guest-set-algebra-v1
  LI r2, 10
  sadd r1, r1, r2                   # SEMANTIC: sadd guest-set-algebra-v1
  LI r3, 11
  LI r4, 2
  srange r1, r1, r3, r4             # SEMANTIC: srange guest-set-algebra-v1
  snew r5
  sadd r5, r5, r3
  ssubset r6, r5, r1                # SEMANTIC: ssubset guest-set-algebra-v1
  LI r7, 1
  BNE r6, r7, bad
  sunion r8, r1, r5                 # SEMANTIC: sunion guest-set-algebra-v1
  ssubset r6, r5, r8
  BNE r6, r7, bad
  sinter r9, r1, r5                 # SEMANTIC: sinter guest-set-algebra-v1
  ssubset r6, r9, r5
  BNE r6, r7, bad
  sremove r10, r1, r3               # SEMANTIC: sremove guest-set-algebra-v1
  ssubset r6, r5, r10
  BNE r6, r0, bad

  # Completion queue empty behavior is stable and non-consuming.
  LI r2, 4
  cqueue.new r11, r0, r2             # SEMANTIC: cqueue.new guest-cqueue-lifecycle-v1
  LI r12, completion_record
  cqueue.recv r6, r11, r12           # SEMANTIC: cqueue.recv guest-cqueue-lifecycle-v1
  LI r7, -8
  BNE r6, r7, bad
  cqueue.peek r6, r11, r12           # SEMANTIC: cqueue.peek guest-cqueue-lifecycle-v1
  BNE r6, r7, bad
  cqueue.destroy r6, r11             # SEMANTIC: cqueue.destroy guest-cqueue-lifecycle-v1
  BNE r6, r0, bad

  # PMU configuration and reset for an engine-owned counter.
  pmu.new r13, r0                    # SEMANTIC: pmu.new guest-pmu-lifecycle-v1
  LI r14, 0
  LI r15, 1
  pmu.event r6, r13, r14, r15        # SEMANTIC: pmu.event guest-pmu-lifecycle-v1
  BNE r6, r0, bad
  LI r16, 100
  pmu.set_threshold r6, r13, r14, r16 # SEMANTIC: pmu.set_threshold guest-pmu-lifecycle-v1
  BNE r6, r0, bad
  pmu.bind_waitable r6, r13, r14     # SEMANTIC: pmu.bind_waitable guest-pmu-lifecycle-v1
  BNE r6, r0, bad
  pmu.read r17, r13, r14             # SEMANTIC: pmu.read guest-pmu-lifecycle-v1
  pmu.reset r6, r13, r14             # SEMANTIC: pmu.reset guest-pmu-lifecycle-v1
  BNE r6, r0, bad
  pmu.read r17, r13, r14
  BNE r17, r0, bad
  pmu.destroy r6, r13                # SEMANTIC: pmu.destroy guest-pmu-lifecycle-v1
  BNE r6, r0, bad

  # IRQ construction consumes the real InterruptSource facet obtained from
  # the STARTUP-discovered SD Device. Raw member capabilities are deliberately
  # absent from CAPS until device.get mints one for the caller.
  irq.new r20, r0                    # SEMANTIC: irq.new guest-irq-builder-v1
  LI r2, 1
  LI r3, 7
  irq.delivery r20, r20, r2, r3      # SEMANTIC: irq.delivery guest-irq-builder-v1
  LI r4, 200
  irq.priority r20, r20, r4          # SEMANTIC: irq.priority guest-irq-builder-v1
  irq.place r20, r20, r0             # SEMANTIC: irq.place guest-irq-builder-v1
  LI r2, 21
  LI r3, 257
  JAL r1, startup_find_profile
  BEQ r2, r0, bad
  LI r3, 3
  device.get r2, r2, r3
  BLE r2, r0, bad
  irq.source r20, r20, r2            # SEMANTIC: irq.source guest-irq-builder-validation-v1
  BLE r20, r0, bad
  irq.seal r21, r20                  # SEMANTIC: irq.seal guest-irq-builder-validation-v1
  BLE r21, r0, bad
  irq.mask r6, r21                   # SEMANTIC: irq.mask guest-irq-live-v1
  BNE r6, r0, bad
  irq.unmask r6, r21                 # SEMANTIC: irq.unmask guest-irq-live-v1
  BNE r6, r0, bad
  irq.ack r6, r21                    # SEMANTIC: irq.ack guest-irq-live-v1
  BNE r6, r0, bad
  LI r3, 1
  irq.ack_mode r6, r21, r3           # SEMANTIC: irq.ack_mode guest-irq-live-v1
  BNE r6, r0, bad
  irq.destroy r6, r21                # SEMANTIC: irq.destroy guest-irq-live-v1
  BNE r6, r0, bad
  irq.new r20, r0
  irq.abort r20                      # SEMANTIC: irq.abort guest-irq-builder-v1

  # DebugTarget against self: context, stepping, watchpoints, and memory copy.
  debug.new r20, r0                  # SEMANTIC: debug.new guest-debug-lifecycle-v1
  LI r2, 1
  channel.new r25, r2
  LI r3, 4
  channel.capacity r25, r25, r3
  channel.producer r25, r25, r0
  channel.consumer r25, r25, r0
  LI r3, 48
  channel.schema r25, r25, r3
  channel.acceptance r25, r25, r0
  channel.seal r26, r25
  debug.bind_events r6, r20, r26     # SEMANTIC: debug.bind_events guest-debug-event-bind-v1
  BNE r6, r0, bad
  GET_PCR r14, THREAD_ID
  LI r15, debug_context
  LI r16, 1200
  debug.read_context r6, r20, r14, r15, r16 # SEMANTIC: debug.read_context guest-debug-lifecycle-v1
  LI r7, 1128
  BNE r6, r7, bad
  LI r14, -1
  LI r17, 1
  debug.set_step r6, r20, r14, r17   # SEMANTIC: debug.set_step guest-debug-stale-tid-v1
  LI r7, -3
  BNE r6, r7, bad
  debug.set_step r6, r20, r14, r0
  BNE r6, r7, bad
  LI r18, debug_source
  LI r19, 8
  LI r17, -1
  debug.set_watch r21, r20, r17, r18, r19, r0 # SEMANTIC: debug.set_watch guest-debug-lifecycle-v1
  BEQ r21, r0, bad
  debug.clear_watch r6, r20, r21     # SEMANTIC: debug.clear_watch guest-debug-lifecycle-v1
  BNE r6, r0, bad
  LI r22, debug_dest
  debug.read_mem r6, r20, r18, r19, r22 # SEMANTIC: debug.read_mem guest-debug-lifecycle-v1
  BNE r6, r19, bad
  LD r23, [r22, 0]
  LD r24, [r18, 0]
  BNE r23, r24, bad
  debug.write_mem r6, r20, r22, r19, r18 # SEMANTIC: debug.write_mem guest-debug-lifecycle-v1
  BNE r6, r19, bad
  debug.write_context r6, r20, r14, r15, r16 # SEMANTIC: debug.write_context guest-debug-validation-v1
  LI r7, -14
  BNE r6, r7, bad
  debug.destroy r6, r20              # SEMANTIC: debug.destroy guest-debug-lifecycle-v1
  BNE r6, r0, bad
  lifecycle.destroy r6, r26
  BNE r6, r0, bad

  # Engine-backed memory and prospective-map lifecycle.
  LI r2, 4096
  backing.new r20, r2, r0            # SEMANTIC: backing.new guest-backing-map-lifecycle-v1
  backing.charge r20, r20, r0        # SEMANTIC: backing.charge guest-backing-map-lifecycle-v1
  backing.seal r21, r20              # SEMANTIC: backing.seal guest-backing-map-lifecycle-v1
  backing.pin_resident r22, r21, r0, r2 # SEMANTIC: backing.pin_resident guest-backing-map-lifecycle-v1
  BEQ r22, r0, bad
  backing.unpin_resident r6, r21, r22 # SEMANTIC: backing.unpin_resident guest-backing-map-lifecycle-v1
  BNE r6, r0, bad
  backing.persist r6, r21, r0, r2    # SEMANTIC: backing.persist guest-backing-map-lifecycle-v1
  BNE r6, r0, bad
  backing.evict r6, r21, r0, r2, 0  # SEMANTIC: backing.evict guest-backing-map-lifecycle-v1
  backing.rehome r6, r21, r0, r2, r0 # SEMANTIC: backing.rehome guest-backing-map-lifecycle-v1
  BNE r6, r0, bad
  GET_PCR r3, DOMAIN_ID
  backing.retarget_charge r6, r21, r3, r3 # SEMANTIC: backing.retarget_charge guest-backing-map-lifecycle-v1
  BNE r6, r0, bad
  backing.clone r23, r21             # SEMANTIC: backing.clone guest-backing-map-lifecycle-v1
  BEQ r23, r0, bad
  writegen.rotate r24, r21           # SEMANTIC: writegen.rotate guest-backing-map-lifecycle-v1
  BEQ r24, r0, bad

  map.new r25, r21, r0, r2          # SEMANTIC: map.new guest-backing-map-lifecycle-v1
  map.private r25, r25               # SEMANTIC: map.private guest-backing-map-lifecycle-v1
  map.anywhere r25, r25              # SEMANTIC: map.anywhere guest-backing-map-lifecycle-v1
  map.reserve r25, r25, r0           # SEMANTIC: map.reserve guest-backing-map-lifecycle-v1
  map.home r25, r25, r0              # SEMANTIC: map.home guest-backing-map-lifecycle-v1
  map.leaf r25, r25, r0              # SEMANTIC: map.leaf guest-backing-map-lifecycle-v1
  map.growdown r25, r25, r0          # SEMANTIC: map.growdown guest-backing-map-lifecycle-v1
  map.type r25, r25, r0              # SEMANTIC: map.type guest-backing-map-lifecycle-v1
  LI r4, 3
  map.protection r25, r25, r4        # SEMANTIC: map.protection guest-backing-map-lifecycle-v1
  map.constrain r25, r25, r0, r0, r2 # SEMANTIC: map.constrain guest-backing-map-lifecycle-v1
  map.prefer r25, r25, r0, r0, r2   # SEMANTIC: map.prefer guest-backing-map-lifecycle-v1
  map.seal r26, r25                  # SEMANTIC: map.seal guest-backing-map-lifecycle-v1
  BEQ r26, r0, bad
  map.populate r6, r26, r2           # SEMANTIC: map.populate guest-backing-map-lifecycle-v1
  BNE r6, r0, bad
  map.protect r6, r26, r2, r4        # SEMANTIC: map.protect guest-backing-map-lifecycle-v1
  BNE r6, r0, bad
  map.reclaimable r6, r26, r2        # SEMANTIC: map.reclaimable guest-backing-map-lifecycle-v1
  LI r7, -5
  BNE r6, r7, bad
  map.discard r6, r26, r2            # SEMANTIC: map.discard guest-backing-map-lifecycle-v1
  BNE r6, r7, bad
  map.demote r6, r26, r2             # SEMANTIC: map.demote guest-backing-map-lifecycle-v1
  munmap_range r6, r26, r2           # SEMANTIC: munmap_range guest-backing-map-lifecycle-v1
  BNE r6, r0, bad

  map.new r27, r21, r0, r2
  map.shared r27, r27                # SEMANTIC: map.shared guest-map-builder-variant-v1
  map.abort r27                      # SEMANTIC: map.abort guest-map-builder-variant-v1
  LI r3, 0x20000
  map.new r27, r21, r0, r2
  map.at r27, r27, r3                # SEMANTIC: map.at guest-map-builder-variant-v1
  map.abort r27
  map.new r27, r21, r0, r2
  map.noreplace r27, r27, r3         # SEMANTIC: map.noreplace guest-map-builder-variant-v1
  map.abort r27

  backing.new r20, r2, r0
  backing.abort r20                  # SEMANTIC: backing.abort guest-backing-abort-v1

  # Object handle allocation follows the startup manifest, which intentionally
  # differs by launch profile. All handle semantics were checked above.
  LI r5, 1
  EXIT r0

# r2 = object class in, capability handle out; r3-r8 clobbered.
startup_find_class:
  ADD r8, r2, r0
  LI r3, 4
  denum.begin r5, r0, r3
  BLE r5, r0, startup_find_miss
  LI r3, startup_record
startup_find_loop:
  cursor.next r6, r5, r3
  BNE r6, r0, startup_find_miss_close
  LW r7, [r3, 8]
  BEQ r7, r8, startup_find_hit
  JMP startup_find_loop
startup_find_hit:
  LD r2, [r3, 0]
  cursor.end r5
  RET
startup_find_miss_close:
  cursor.end r5
startup_find_miss:
  LI r2, 0
  RET

# r2 = object class and r3 = profile in, capability handle out; r3-r9 clobbered.
startup_find_profile:
  ADD r8, r2, r0
  ADD r9, r3, r0
  LI r3, 4
  denum.begin r5, r0, r3
  BLE r5, r0, startup_find_profile_miss
  LI r3, startup_record
startup_find_profile_loop:
  cursor.next r6, r5, r3
  BNE r6, r0, startup_find_profile_miss_close
  LW r7, [r3, 8]
  BNE r7, r8, startup_find_profile_loop
  LW r7, [r3, 12]
  BNE r7, r9, startup_find_profile_loop
  LD r2, [r3, 0]
  cursor.end r5
  RET
startup_find_profile_miss_close:
  cursor.end r5
startup_find_profile_miss:
  LI r2, 0
  RET
bad:
  LI r1, 1
  EXIT r1
