# SPDX-FileCopyrightText: 2026 Deep AI, Inc.
# SPDX-License-Identifier: Apache-2.0
# Guest-checked WorkQueue builder and reusable-boundary lifecycle.
.text
  LI r2, 8
  cqueue.new r10, r0, r2

  # Mint an ordinary software Device so this semantic proof is identical in
  # bare, SoC, and hosted-dev. Platform reset discovery is tested separately.
  LI r2, 257
  device.new r2, r2
  device.seal r2, r2
  BEQ r2, r0, bad
  ADDI r11, r2, 0

  LI r2, 4
  LI r3, 64
  workqueue.new r12, r0, r2, r3        # SEMANTIC: workqueue.new guest-workqueue-v1
  workqueue.device r12, r12, r11       # SEMANTIC: workqueue.device guest-workqueue-v1
  workqueue.completion r12, r12, r10   # SEMANTIC: workqueue.completion guest-workqueue-v1
  workqueue.seal r13, r12              # SEMANTIC: workqueue.seal guest-workqueue-v1
  BLE r13, r0, bad

  LI r2, 0
  workqueue.get r14, r13, r2           # SEMANTIC: workqueue.get guest-workqueue-v1
  LI r3, 4
  BNE r14, r3, bad
  LI r2, 1
  workqueue.set_blocking r14, r13, r2  # SEMANTIC: workqueue.set_blocking guest-workqueue-v1
  BNE r14, r0, bad
  LI r2, 3
  queue.drain r14, r13, r0, r2         # SEMANTIC: queue.drain guest-workqueue-v1
  BNE r14, r0, bad

  # Unknown activities are generation-stale and do not disturb the queue.
  LI r2, 0x1234
  activity.cancel r14, r2              # SEMANTIC: activity.cancel guest-activity-stale-v1
  LI r3, -3
  BNE r14, r3, bad

  workqueue.teardown r14, r13           # SEMANTIC: workqueue.teardown guest-workqueue-v1
  BNE r14, r0, bad

  LI r2, 4
  LI r3, 64
  workqueue.new r12, r0, r2, r3
  workqueue.abort r12                   # SEMANTIC: workqueue.abort guest-workqueue-abort-v1
  cqueue.destroy r1, r10
  lifecycle.destroy r1, r11
  EXIT r0
bad:
  LI r1, 1
  EXIT r1
